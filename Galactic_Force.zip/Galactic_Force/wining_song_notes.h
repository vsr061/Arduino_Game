

//Musical Note Frequencies
unsigned int C6 = 1047;
unsigned int Ab5 = 831;
unsigned int Bb5 = 932;
unsigned int G5 = 784;
unsigned int F5 = 698;
unsigned int E5 = 659;
unsigned int Eb5 = 622;
unsigned int D5 = 587;
unsigned int Db5 = 554;
unsigned int C5 = 523;
unsigned int B4 = 494;
unsigned int Bb4 = 466;
unsigned int nA4 = 440;
unsigned int Ab4 = 415;
unsigned int G4 = 392;
unsigned int Gb4 = 370;
unsigned int F4 = 349;
unsigned int E4 = 330;
unsigned int Eb4 = 311;
unsigned int D4 = 294;
unsigned int Db4 = 277;
unsigned int C4 = 262;
unsigned int B3 = 247;
unsigned int Bb3 = 233;
unsigned int nA3 = 220;
unsigned int G3 = 196;
unsigned int Gb3 = 185;
unsigned int F3 = 175;
unsigned int E3 = 165;

 
